-- MySQL dump 10.13  Distrib 8.0.40, for macos14 (arm64)
--
-- Host: localhost    Database: cinema_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `movie_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text,
  `duration` int DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `poster_url` varchar(255) DEFAULT NULL,
  `status` enum('NOW_SHOWING','COMING_SOON','ENDED') DEFAULT 'COMING_SOON',
  PRIMARY KEY (`movie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'Red One 2024','After Santa Claus is kidnapped, the North Pole\'s Head of Security must team up with a notorious hacker in a globe-trotting, action-packed mission to save Christmas.',123,'2024-11-15',4.8,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735794261/movie_posters/xdrojix4v1hwitsjoyza.jpg','NOW_SHOWING'),(2,'Dune: Part Two 2024','Paul Atreides unites with the Fremen while on a warpath of revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe, he endeavors to prevent a terrible future.',166,'2025-01-03',4.9,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735801109/movie_posters/la4d5xaaamedbvvgrpk9.jpg','NOW_SHOWING'),(6,'Captain America: Brave New World 2025','Sam Wilson, the new Captain America, finds himself in the middle of an international incident and must discover the motive behind a nefarious global plan.',0,'2025-02-14',0.0,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735806796/movie_posters/cd7kokiqjix9kngrymma.jpg','COMING_SOON'),(7,'Thunderbolts 2025','A group of supervillains are recruited to go on missions for the government.\r\n',0,'2025-05-02',0.0,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735806947/movie_posters/plge2vgt33tjuos0gx2x.jpg','COMING_SOON'),(8,'Den of Thieves 2: Pantera (2025)','Gerard Butler (Plane, Has Fallen series) and OâShea Jackson Jr. (Straight Out of Compton, Godzilla: King of the Monsters) return in the sequel to 2018\'s action-heist hit Den of Thieves. In DEN OF THIEVES: PANTERA, Big Nick (Butler) is back on the hunt in Europe and closing in on Donnie (Jackson), who is embroiled in the treacherous and unpredictable world of diamond thieves and the infamous Panther mafia, as they plot a massive heist of the world\'s largest diamond exchange.',124,'2025-01-10',0.0,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735807096/movie_posters/vmx2twi6qdvddrynja4o.jpg','COMING_SOON'),(9,'Survive 2024','In SURVIVE, Julia and her loving husband celebrate their son\'s birthday on their boat in the middle of the ocean. When a violent storm nearly capsizes them, the family awakes in a desert land. Earth has undergone a tragic polarity reversal, draining water from the oceans. The family must race to safety before the water returns all while battling hungry creatures from the abyss that hunt for fresh flesh.',90,'2024-01-09',4.6,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735807302/movie_posters/z4irddhn6nbeetxkobvt.jpg','NOW_SHOWING'),(10,'Putin 2024','The story of Russian President Vladimir Putin -- from his life as a troubled child to his ruthless ascent to power.',109,'2024-07-02',3.8,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735807548/movie_posters/zfxdzxj0c9c0ste4mbpk.jpg','ENDED'),(11,'Black Diamond 2023','After moving into a secluded cabin, a young woman and her boyfriend meet a local cowboy handyman, turning their idyllic life into a deadly triangle of lust, obsession, and murder.',89,'2023-01-10',4.8,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735807788/movie_posters/h3md2jx0jwzwghkold2f.jpg','ENDED'),(12,'Babygirl 2024','A high-powered CEO puts her career and family on the line when she begins a torrid affair with her much-younger intern.',114,'2025-01-10',4.9,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735807991/movie_posters/z37hswacgbnz7bicfkh6.jpg','COMING_SOON'),(13,'The Lorax 2012 (Christmas special)','A 12-year-old boy searches for the one thing that will enable him to win the affection of the girl of his dreams. To find it he must discover the story of the Lorax, the grumpy yet charming creature who fights to protect his world.',86,'2012-01-01',4.7,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735808218/movie_posters/meuh2np5ywunqzomlyht.jpg','NOW_SHOWING'),(14,'Don\'t Die: The Man Who Wants to Live Forever 2025','Explores a man\'s quest for immortality and the lengths he goes to defy aging.\r\n',88,'2025-01-01',4.8,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735808435/movie_posters/ejlcwzhtyydtdklqrqlk.jpg','NOW_SHOWING'),(15,'Avatar: The Way of Water 2022','Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na\'vi race to protect their home.\r\n',112,'2022-05-12',5.0,'https://res.cloudinary.com/dzytk7ias/image/upload/v1735808615/movie_posters/ts595fpigsyujonopkzl.jpg','NOW_SHOWING');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-03  1:51:34
